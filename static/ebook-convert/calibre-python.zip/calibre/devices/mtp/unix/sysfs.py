#!/usr/bin/env python


__license__   = 'GPL v3'
__copyright__ = '2013, Kovid Goyal <kovid at kovidgoyal.net>'
__docformat__ = 'restructuredtext en'

import glob
import os


class MTPDetect:

    SYSFS_PATH = os.environ.get('SYSFS_PATH', '/sys')

    def __init__(self):
        self.base = os.path.join(self.SYSFS_PATH, 'subsystem', 'usb', 'devices')
        if not os.path.exists(self.base):
            self.base = os.path.join(self.SYSFS_PATH, 'bus', 'usb', 'devices')
        self.ok = os.path.exists(self.base)

    def __call__(self, dev, debug=None):
        '''
        Check if the device has an interface named "MTP" using sysfs, which
        avoids probing the device.
        '''
        if not self.ok:
            return False

        def read(x):
            try:
                with open(x, 'rb') as f:
                    return f.read()
            except OSError:
                pass

        ipath = os.path.join(self.base, f'{dev.busnum}-*/{dev.busnum}-*/interface')
        for x in glob.glob(ipath):
            raw = read(x)
            if not raw or raw.strip() != b'MTP':
                continue
            raw = read(os.path.join(os.path.dirname(os.path.dirname(x)),
                                    'devnum'))
            try:
                if raw and int(raw) == dev.devnum:
                    if debug is not None:
                        debug(f'Unknown device {dev} claims to be an MTP device'
                              )
                    return True
            except (ValueError, TypeError):
                continue

        return False
