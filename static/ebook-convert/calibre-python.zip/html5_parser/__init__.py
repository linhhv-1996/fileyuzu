"""
WASM-compatible html5_parser replacement.

Uses lxml.html for lxml tree output. When return_root=False, returns a
bs4.BeautifulSoup object (needed by calibre's BeautifulSoup wrapper).

The native html5-parser C extension (based on Gumbo) cannot run in WASM.
"""

from copy import deepcopy
from lxml import etree, html as lxml_html

XHTML_NS = 'http://www.w3.org/1999/xhtml'

def _decode(html, transport_encoding=None, fallback_encoding=None):
    if isinstance(html, bytes):

        if html[:3] == b'\xef\xbb\xbf':
            return html[3:].decode('utf-8', 'replace')
        if html[:2] in (b'\xff\xfe', b'\xfe\xff'):
            return html.decode('utf-16', 'replace')

        if html[:5] == b'<?xml':
            import re
            m = re.search(rb'encoding=["\']([^"\']+)', html[:200])
            if m:
                enc = m.group(1).decode('ascii', 'replace')
                try:
                    return html.decode(enc)
                except (UnicodeDecodeError, LookupError):
                    pass

        encoding = transport_encoding or fallback_encoding or 'utf-8'
        try:
            return html.decode(encoding)
        except (UnicodeDecodeError, LookupError):
            try:
                return html.decode('utf-8', 'replace')
            except Exception:
                return html.decode('latin-1', 'replace')
    return html

def _is_xhtml(html_str):
    """Detect if content is XHTML based on namespace or content type."""
    if 'xmlns="http://www.w3.org/1999/xhtml"' in html_str[:1000]:
        return True
    if 'application/xhtml+xml' in html_str[:500]:
        return True
    return False

def parse(html, treebuilder='lxml', namespaceHTMLElements=False,
          transport_encoding=None, fallback_encoding=None,
          maybe_xhtml=False, sanitize_names=False, return_root=True, **kwargs):
    """Parse HTML5 document.

    When return_root=True (default), returns an lxml element tree.
    When return_root=False, returns a bs4.BeautifulSoup object.
    """
    html = _decode(html, transport_encoding, fallback_encoding)

    if not return_root:
        import bs4
        return bs4.BeautifulSoup(html, 'html.parser')

    # Try XML parse first (handles well-formed XHTML)
    if maybe_xhtml or _is_xhtml(html):
        try:
            parser = etree.XMLParser(recover=True, no_network=True,
                                     resolve_entities=False)
            root = etree.fromstring(html.encode('utf-8'), parser=parser)
            if root is not None and root.tag is not None:
                tag = root.tag
                if isinstance(tag, str):
                    local = tag.split('}')[-1] if '}' in tag else tag
                    if local.lower() == 'html':
                        _ensure_namespace(root, XHTML_NS)
                        return root
        except Exception:
            pass

    # Fallback: parse as lenient HTML
    try:
        html_root = lxml_html.document_fromstring(html)
    except Exception:
        try:
            parser = lxml_html.HTMLParser(recover=True)
            html_root = lxml_html.document_fromstring(html, parser=parser)
        except Exception:
            html_root = lxml_html.document_fromstring('<html><body></body></html>')

    # lxml.html returns HtmlElement objects which silently strip namespaces
    # when you set .tag. We must walk the tree and build a new lxml.etree
    # tree with proper XHTML namespace tags.
    need_xhtml = maybe_xhtml or not kwargs.get('discard_namespaces', False)
    if need_xhtml:
        return _build_xhtml_tree(html_root)

    return html_root


def _build_xhtml_tree(html_root):
    """Walk an lxml.html tree and build a new lxml.etree tree with XHTML namespace.

    This is necessary because lxml.html HtmlElement objects silently strip
    namespace prefixes from .tag, making it impossible to set XHTML namespaces
    on them. By building a fresh etree with Element (not HtmlElement), the
    namespace sticks.
    """
    ns = XHTML_NS
    nsmap = {None: ns}

    def _convert(el, set_nsmap=False):
        tag = el.tag
        # Comments, PIs, etc. have non-string tags (callables)
        if not isinstance(tag, str):
            return deepcopy(el)

        # Add XHTML namespace to bare tags
        if not tag.startswith('{'):
            tag = f'{{{ns}}}{tag}'

        # Create new element — only set nsmap on root to avoid redundant xmlns decls
        if set_nsmap:
            new_el = etree.Element(tag, attrib=dict(el.attrib), nsmap=nsmap)
        else:
            new_el = etree.Element(tag, attrib=dict(el.attrib))

        new_el.text = el.text
        new_el.tail = el.tail

        for child in el:
            new_child = _convert(child)
            if new_child is not None:
                new_el.append(new_child)

        return new_el

    return _convert(html_root, set_nsmap=True)


def _ensure_namespace(root, ns):
    """Add XHTML namespace to etree _Element nodes that lack one.

    Only works on regular etree._Element, NOT on lxml.html.HtmlElement.
    """
    ns_prefix = f"{{{ns}}}"
    for el in root.iter():
        if isinstance(el.tag, str) and not el.tag.startswith('{'):
            el.tag = ns_prefix + el.tag
